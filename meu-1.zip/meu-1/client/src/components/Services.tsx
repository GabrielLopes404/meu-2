import { useQuery } from "@tanstack/react-query";
import { Palette, Image, Box, Monitor, Sparkles, ChevronRight } from "lucide-react";
import type { Service } from "@shared/schema";

const iconMap: Record<string, any> = {
  palette: Palette,
  image: Image,
  box: Box,
  monitor: Monitor,
  sparkles: Sparkles,
};

export function Services() {
  const { data: services = [], isLoading, isError } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  if (isError) {
    return (
      <section id="servicos" className="py-24 bg-[#050505] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-8">
            <p className="text-red-400 text-lg">Erro ao carregar serviços. Tente novamente mais tarde.</p>
          </div>
        </div>
      </section>
    );
  }

  if (isLoading) {
    return (
      <section id="servicos" className="py-20 md:py-32 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="h-12 w-64 mx-auto bg-muted animate-pulse rounded" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-96 bg-muted animate-pulse rounded-lg" data-testid={`skeleton-service-${i}`} />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="servicos" className="py-24 bg-[#050505] text-white relative overflow-hidden" data-testid="section-services">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_top_right,#ff00c366,transparent_55%)] opacity-40"></div>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight text-white" data-testid="text-services-title">
            Veja o que posso transformar
            <br />
            <span className="text-primary">na sua marca</span>
          </h2>
          <p className="text-lg text-white/60 max-w-3xl mx-auto leading-relaxed">
            Transformo sua marca com design estratégico, pensado pra atrair, encantar e vender — tudo com visual profissional e preço acessível.
          </p>
        </div>

        <div className="relative -mx-4 md:mx-0">
          <div className="md:hidden absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-[#050505] via-[#050505]/80 to-transparent z-10 pointer-events-none flex items-center justify-start pl-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center animate-pulse">
              <ChevronRight className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div className="md:hidden absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#050505] via-[#050505]/80 to-transparent z-10 pointer-events-none flex items-center justify-end pr-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center animate-pulse">
              <ChevronRight className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div className="md:grid md:grid-cols-2 xl:grid-cols-3 md:gap-10 flex overflow-x-auto gap-6 pb-4 snap-x snap-mandatory scrollbar-hide scroll-smooth-touch px-4 md:px-0">
            {services.map((service, index) => {
            const Icon = iconMap[service.icon] || Sparkles;
            return (
              <div
                key={service.id}
                className="group rounded-3xl bg-[#131313] border border-white/5 hover:border-primary/50 transition-all duration-300 hover:-translate-y-2 p-8 min-h-[360px] flex flex-col relative overflow-hidden min-w-[85vw] md:min-w-0 snap-center"
                data-testid={`card-service-${index}`}
              >
                <div className="absolute top-0 right-0 w-40 h-40 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/10 transition-colors"></div>
                
                <div className="relative z-10 flex flex-col h-full">
                  <div className="mb-6">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center border border-primary/20 group-hover:border-primary/40 transition-colors shadow-lg">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                  </div>

                  <h3 className="font-display font-bold text-2xl mb-4 text-white" data-testid={`text-service-title-${index}`}>
                    {service.title}
                  </h3>

                  <p className="text-base text-white/70 leading-relaxed mt-3 flex-grow" data-testid={`text-service-desc-${index}`}>
                    {service.description}
                  </p>

                  <div className="mt-10">
                    <button className="inline-flex items-center gap-2 text-primary font-semibold text-sm uppercase tracking-wide hover:gap-3 transition-all group-hover:text-primary">
                      VER EXEMPLOS
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
