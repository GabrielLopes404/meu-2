import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Quote } from "lucide-react";
import type { Testimonial } from "@shared/schema";

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { data: testimonials = [], isLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  useEffect(() => {
    if (testimonials.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  if (isLoading) {
    return (
      <section id="depoimentos" className="py-20 md:py-32 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-12 w-64 mx-auto bg-muted animate-pulse rounded mb-16" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2].map((i) => (
              <div key={i} className="h-64 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  const visibleTestimonials =
    testimonials.length > 1
      ? [
          testimonials[currentIndex],
          testimonials[(currentIndex + 1) % testimonials.length],
        ]
      : testimonials;

  return (
    <section id="depoimentos" className="py-20 md:py-32 bg-card" data-testid="section-testimonials">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight" data-testid="text-testimonials-title">
            Quem Já Contratou <span className="text-primary">Recomenda</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Veja o que dizem aqueles que já confiaram no nosso trabalho e transformaram suas ideias em projetos de sucesso.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {visibleTestimonials.map((testimonial, index) => (
            <Card
              key={testimonial.id}
              className="p-8 bg-background border-card-border min-h-[300px] flex flex-col relative overflow-hidden group hover-elevate"
              data-testid={`testimonial-card-${index}`}
            >
              <Quote className="absolute top-6 left-6 w-8 h-8 text-primary/20" />

              <div className="relative z-10 flex-grow">
                <p className="text-lg leading-relaxed mb-6 text-foreground" data-testid={`text-testimonial-${index}`}>
                  "{testimonial.text}"
                </p>
              </div>

              <div className="flex items-center gap-4 mt-auto">
                <Avatar className="w-12 h-12" data-testid={`avatar-testimonial-${index}`}>
                  <AvatarImage src={testimonial.avatarUrl} />
                  <AvatarFallback className="bg-primary/10 text-primary font-bold">
                    {testimonial.author
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()
                      .slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-display font-bold text-foreground" data-testid={`text-testimonial-author-${index}`}>
                    {testimonial.author}
                  </div>
                  <div className="text-sm text-muted-foreground">Cliente Satisfeito</div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="flex items-center justify-center gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex ? "bg-primary w-8" : "bg-muted"
              }`}
              data-testid={`dot-testimonial-${index}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
