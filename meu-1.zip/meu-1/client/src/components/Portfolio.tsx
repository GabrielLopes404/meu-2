import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { X } from "lucide-react";
import type { PortfolioItem } from "@shared/schema";

const categories = ["Todos", "Identidade Visual", "Social Media", "3D", "Web/App"];

export function Portfolio() {
  const [activeFilter, setActiveFilter] = useState("Todos");
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  const { data: items = [], isLoading } = useQuery<PortfolioItem[]>({
    queryKey: ["/api/portfolio"],
  });

  const filteredItems =
    activeFilter === "Todos"
      ? items
      : items.filter((item) => item.category === activeFilter);

  if (isLoading) {
    return (
      <section id="portfolio" className="py-20 md:py-32 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-12 w-64 mx-auto bg-muted animate-pulse rounded mb-16" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-80 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section id="portfolio" className="py-24 bg-[#050505] relative overflow-hidden" data-testid="section-portfolio">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12 space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/40 mb-4 shadow-[0_0_20px_rgba(236,72,153,0.3)]">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
              <span className="text-sm font-medium text-primary uppercase tracking-wider">Meu Trabalho</span>
            </div>
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight text-white" data-testid="text-portfolio-title">
              Meu Portfolio de <span className="text-primary">Impacto</span>
            </h2>
            <p className="text-lg text-white/60 max-w-3xl mx-auto leading-relaxed">
              <span className="font-bold text-primary">Transformo sua marca com design estratégico, pensado pra atrair, encantar e vender</span> — tudo <span className="text-white font-semibold">100% profissional</span> e a <span className="text-white font-semibold">preço justo</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-2 rounded-full font-medium text-sm uppercase tracking-wider transition-all ${
                  activeFilter === category
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
                data-testid={`filter-${category.toLowerCase().replace(/\//g, "-")}`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="md:grid md:grid-cols-2 xl:grid-cols-3 md:auto-rows-[260px] md:gap-8 flex overflow-x-auto gap-6 pb-4 snap-x snap-mandatory scrollbar-hide scroll-smooth-touch -mx-4 px-4 md:mx-0 md:px-0">
            {filteredItems.length === 0 ? (
              <div className="col-span-full text-center py-20">
                <p className="text-white/60 text-lg">Nenhum projeto encontrado nesta categoria.</p>
              </div>
            ) : (
              filteredItems.map((item, index) => {
                const isLarge = index % 5 === 0;
                return (
                  <div
                    key={item.id}
                    className={`group relative overflow-hidden cursor-pointer rounded-3xl bg-[#101010] border border-white/10 hover:border-primary/40 transition-all duration-500 min-w-[85vw] md:min-w-0 snap-center flex-shrink-0 h-[400px] md:h-auto ${
                      isLarge ? 'md:row-span-2' : ''
                    }`}
                    onClick={() => setSelectedItem(item)}
                    data-testid={`portfolio-item-${index}`}
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="absolute inset-0 w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-700"
                    />
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-60 group-hover:opacity-100 transition-opacity duration-500"></div>
                    
                    <div className="absolute top-5 left-5 z-20">
                      <div className="px-4 py-1 rounded-full bg-primary text-white text-xs font-semibold uppercase shadow-lg" data-testid={`badge-category-${index}`}>
                        {item.category}
                      </div>
                    </div>
                    
                    <div className="absolute inset-x-5 bottom-5 space-y-2 text-left z-20 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                      <h3 className="font-display font-bold text-xl md:text-2xl text-white drop-shadow-lg" data-testid={`text-portfolio-title-${index}`}>
                        {item.title}
                      </h3>
                      {item.client && (
                        <p className="text-sm text-white/80 font-medium" data-testid={`text-portfolio-client-${index}`}>
                          Cliente: {item.client}
                        </p>
                      )}
                      <div className="flex items-center gap-2 text-xs text-primary font-semibold uppercase tracking-wider pt-2">
                        <span>VER DETALHES</span>
                        <svg className="w-3 h-3 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </div>

                    <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </section>

      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-background border-border" aria-describedby="dialog-description">
          {selectedItem && (
            <div className="relative" data-testid="lightbox-modal">
              <DialogTitle className="sr-only">{selectedItem.title}</DialogTitle>
              <DialogDescription id="dialog-description" className="sr-only">
                {selectedItem.description || `Detalhes do projeto ${selectedItem.title}`}
              </DialogDescription>
              
              <button
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 z-50 p-2 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background transition-colors"
                data-testid="button-close-lightbox"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="aspect-square w-full">
                <img
                  src={selectedItem.imageUrl}
                  alt={selectedItem.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="p-8 space-y-4">
                <div className="flex items-center gap-3">
                  <Badge data-testid="badge-lightbox-category">{selectedItem.category}</Badge>
                  {selectedItem.client && (
                    <span className="text-sm text-muted-foreground" data-testid="text-lightbox-client">{selectedItem.client}</span>
                  )}
                </div>
                <h3 className="font-display font-bold text-3xl text-foreground" data-testid="text-lightbox-title">
                  {selectedItem.title}
                </h3>
                {selectedItem.description && (
                  <p className="text-muted-foreground leading-relaxed" data-testid="text-lightbox-description">
                    {selectedItem.description}
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
